public enum Shapetype{
   
    RECTANGLE,TRAPEZOID,L_SHAPE;

}