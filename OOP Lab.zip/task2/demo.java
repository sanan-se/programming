public class demo{

public static void main(String args[]){

Student s;

s=new Student();


System.out.println("Student Details:");



}
}