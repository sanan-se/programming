//Name:M .Sanan Umar
//Registration No:SP25-BCS-061


public class Student{

private String name;
private String email;
private double cgpa;

public void display(String name, String email, double cgpa){
this.name=name;
this.email=email;
this.cgpa=cgpa;

}

public Student(String name, String email, double cgpa){
this.name=name;
this.email=email;
this.cgpa=cgpa;

public void SetStudent(String name, String email, double cgpa){


this.name=name;
this.email=email;
this.cgpa=cgpa;



}