//Name: M.Sanan Umar
//REg no: SP25-BCS-061

public class student{
private String name;
private string email;
private double CGPA;
display (){
this.name.name;

