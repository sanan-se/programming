public class demo{
public static void main (string []args){
student s;
s= new Student();
s.name = "M.Sanan Umar";
s.email = "msananuar23@gmail.com";
s.cgpa = 3.7;
display()